tar -zcvf ../instalacion.tar.gz . && cd ..
